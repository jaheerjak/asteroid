using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletPower : MonoBehaviour
{
    public void OnClick()
    {
        GameManager._instance.PowerActive();
        Destroy(gameObject);
    }
}
