using System;
using UnityEngine;

[Serializable]
public class ConfigList
{
    public float _playerMoveSpeed;
    public float _turnSpeed;
    public float _bulletSpeed;
    public float _bulletLifeTime;
    public float _asteroidLifeTime;
    public float asteroidSpeed;

    public int maxLives;
    public int respawnTime;
    public int respawnColidedTime;
    public int shieldRespawnTime;
    public int bulletPowerRespawnTime;
}
[CreateAssetMenu(fileName = "GameConfig", menuName = "GameConfigMenu", order = 1)]
public class GameConfig : ScriptableObject
{
    public ConfigList _configData;
}
