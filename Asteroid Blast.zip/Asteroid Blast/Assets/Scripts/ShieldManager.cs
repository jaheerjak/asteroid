using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldManager : MonoBehaviour
{
    public void OnClick()
    {
        GameManager._instance.ShieldActive();
        Destroy(gameObject);
    }
}
