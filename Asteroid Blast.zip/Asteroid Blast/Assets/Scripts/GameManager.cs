using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;

public class GameManager : MonoBehaviour
{
    public static GameManager _instance;
    public bool isGameOver = false;
    public bool initilized = false;
    public bool isPowerActive = false;
    public bool isShieldActive = false;
    public PlayerManager _player;
    //public Bull _player;

    [SerializeField] GameConfig config;
    [SerializeField] int lives;
    [SerializeField] int score;
    [SerializeField] ParticleSystem explosion;
    [SerializeField] AsteroidSpawn asteroidSpawn;

    [Space]
    [SerializeField] GameObject[] lifeHearts;
    [SerializeField] TMP_Text scoreTxt;
    [SerializeField] GameObject retryPanel;
    [SerializeField] GameObject startPanel;

    [Space]
    [SerializeField] Image powerFillImage;
    [SerializeField] Image shieldFillImage;
    [SerializeField] int fillTime;
    [SerializeField] GameObject shieldPefab;
    [SerializeField] GameObject powerPefab;
    [SerializeField] Transform powerParent;
    private void Awake()
    {
        _instance = this;
        initilized = false;
        isPowerActive = false;
        isShieldActive = false;
        lives = config._configData.maxLives;
        retryPanel.SetActive(false);
    }
    public void Asteroidestroyed(AsteroidManager asteroid)
    {
        explosion.transform.position = asteroid.transform.position;
        explosion.Play();
        if (asteroid.actualSize < 0.8f)
            score += 100;
        else if (asteroid.actualSize < 1.25f)
            score += 50;
        else 
            score += 25;

        scoreTxt.text = "Score:" + score;

    }
    bool hitted = false;
    public void GameOver()
    {        
        explosion.transform.position = _player.transform.position;
        explosion.Play();
        lifeHearts[lives - 1].SetActive(false);
        lives--;
        
        if (lives <= 0)
        {
            isGameOver = true;
            retryPanel.SetActive(true);
            Debug.Log("GameOver");
        }
        else
        {
            hitted = true;
            Invoke(nameof(ReSpawn), config._configData.respawnTime);
        }
    }
    void ReSpawn()
    {
        _player.transform.position = Vector3.zero;
        _player.gameObject.layer = LayerMask.NameToLayer("IgnoreCollision");
        _player.gameObject.SetActive(true);
        Debug.Log("ReSpawn");
        Invoke(nameof(ChangetoNormalLayer), config._configData.respawnColidedTime);
    }
    void ChangetoNormalLayer()
    {
        hitted = false;
        _player.gameObject.layer = LayerMask.NameToLayer("Player");
        CancelInvoke(nameof(ChangetoNormalLayer));
    }
    public void Onclick_Start()
    {
        initilized = true;
        startPanel.SetActive(false);
        asteroidSpawn.OnInit();
        GenerateShield();
    }
    public void Restart()
    {
        lives = config._configData.maxLives;
        score = 0;
        isGameOver = false;
        retryPanel.SetActive(false);
        ReSpawn();
        SceneManager.LoadScene("Asteroid");

    }

    public void PowerActive()
    {
        isPowerActive = true;
        GenerateShield();
        Invoke(nameof(ChangePower), config._configData.bulletPowerRespawnTime);
    }
    void ChangePower()
    {
        isPowerActive = false;
        //._shield.SetActive(false);
    }
    public void ShieldActive()
    {
        isShieldActive = true;
        _player._shield.SetActive(true);
        GenerateBulletPower();
        Invoke(nameof(HideShield), config._configData.shieldRespawnTime);
    }
    void HideShield()
    {
        isShieldActive = false;
        _player._shield.SetActive(false);
    }
    public void GenerateShield()
    {
        shieldFillImage.fillAmount = 0;
        shieldFillImage.DOFillAmount(1, fillTime)
            .OnComplete(()=>
            {
                GameObject gb = Instantiate(shieldPefab, powerParent);
            });
    }
    public void GenerateBulletPower()
    {
        powerFillImage.fillAmount = 0;
        powerFillImage.DOFillAmount(1, fillTime)
            .OnComplete(() =>
            {
                GameObject gb = Instantiate(powerPefab, powerParent);
            });
    }
}
