using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletManager : MonoBehaviour
{
    private Rigidbody2D _rb;
    [SerializeField] GameConfig _config;
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] Sprite[] sprites;
    private void Awake()
    {
        _rb = GetComponent<Rigidbody2D>();
    }
    public void BulletDirection(Vector2 direction)
    {
        if (GameManager._instance.isPowerActive)
            spriteRenderer.sprite = sprites[1];
        else
            spriteRenderer.sprite = sprites[0];
        _rb.AddForce(direction * _config._configData._bulletSpeed);
        Destroy(gameObject, _config._configData._bulletLifeTime);

    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Destroy(gameObject);
    }
}
