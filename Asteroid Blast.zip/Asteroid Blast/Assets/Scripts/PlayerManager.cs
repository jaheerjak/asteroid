using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    private bool _forceToMove;
    private float _direction;
    [SerializeField] Rigidbody2D _rb;
    [SerializeField] GameConfig configData;
    [SerializeField] GameObject _bullet;
    public GameObject _shield;
    // Update is called once per frame
    private void Update()
    {
        if (!GameManager._instance.initilized || !gameObject.activeSelf)
            return;
        _forceToMove = Input.GetKey(KeyCode.UpArrow);
        if (Input.GetKey(KeyCode.RightArrow))
        {
            _direction = -1.0f;
        }
        else if (Input.GetKey(KeyCode.LeftArrow))
        {
            _direction = 1.0f;
        }
        else
            _direction = 0.0f;

        //--------Shoot
        if (Input.GetKeyDown(KeyCode.Space) && gameObject.activeSelf)
            Shoot();
    }
    private void FixedUpdate()
    {
        if (!GameManager._instance.initilized || !gameObject.activeSelf)
            return;
        if (_forceToMove)
        {
            _rb.AddForce(transform.up* configData._configData._playerMoveSpeed);
        }
        if(_direction!=0)
        {
            _rb.AddTorque(_direction * configData._configData._turnSpeed);
        }
    }
    public void Shoot()
    {
        GameObject bullet = Instantiate(_bullet, transform.position, transform.rotation);
        bullet.GetComponent<BulletManager>().BulletDirection(transform.up);
        Debug.Log("bullet"+ bullet.name);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (GameManager._instance.isShieldActive)
            return;
        if (collision.gameObject.tag == "Asteroid"&&gameObject.activeSelf)
        {
           
            _rb.velocity = Vector3.zero;
            _rb.angularVelocity= 0f;
            gameObject.SetActive(false);
            GameManager._instance.GameOver();
        }
    }
}
