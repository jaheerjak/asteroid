using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidManager : MonoBehaviour
{
    [SerializeField] Sprite[] _spriteList;
    [SerializeField] SpriteRenderer _spriteRenderer;
    [SerializeField] Rigidbody2D _rb;
    [SerializeField] GameConfig configData;
    public float actualSize=1f;
    public float minSize=0.5f;
    public float maxSize=1.5f;

    void Start()
    {
        _spriteRenderer.sprite = _spriteList[Random.Range(0, _spriteList.Length)];
        transform.eulerAngles = new Vector3(0, 0, Random.value * 360f);
        transform.localScale = Vector3.one * actualSize;
        _rb.mass = actualSize*2.0f;
    }
    public void SetAsteroid(Vector2 direction)
    {
        _rb.AddForce(direction * configData._configData.asteroidSpeed);
        Destroy(gameObject, configData._configData._asteroidLifeTime);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("tag " + collision.gameObject.tag);
        if(collision.gameObject.tag=="Bullet")
        {
            if(((actualSize*0.5f)>=minSize) && !GameManager._instance.isPowerActive)
            {
                SplitObject();
                SplitObject();
            }
            GameManager._instance.Asteroidestroyed(this);
            Destroy(gameObject);
        }
    }
    void SplitObject()
    {
        
            Vector2 pos = transform.position;
            pos += Random.insideUnitCircle * 0.5f;
            AsteroidManager half = Instantiate(this, pos, transform.rotation);
            half.actualSize = actualSize * 0.5f;
            half.SetAsteroid(Random.insideUnitCircle.normalized *configData._configData.asteroidSpeed);
        
    }
}

    
