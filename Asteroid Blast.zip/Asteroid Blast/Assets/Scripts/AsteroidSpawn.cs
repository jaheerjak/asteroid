using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidSpawn : MonoBehaviour
{
    [SerializeField] AsteroidManager _asteroid;
    [SerializeField] float spawnRate = 2.0f;
    [SerializeField] int spawnAmount = 1;
    [SerializeField] float spawnDistance = 15f;
    [SerializeField] float spawnVariance = 15f;
    public void OnInit()
    {
        InvokeRepeating(nameof(Spawn), spawnRate, spawnRate);

    }
    void Spawn()
    {
        if (GameManager._instance.isGameOver)
            return;
        for(int i=0;i<spawnAmount;i++)
        {
            Vector3 spawnDirection=Random.insideUnitCircle.normalized*spawnDistance;
            Vector3 spawnPoint = transform.position + spawnDirection;
            float variance = Random.Range(-spawnVariance, spawnVariance);
            Quaternion rotation=Quaternion.AngleAxis(variance,Vector3.forward);
            AsteroidManager asteroid = Instantiate(_asteroid, spawnPoint, rotation);
            asteroid.actualSize = Random.Range(asteroid.minSize, asteroid.maxSize);
            asteroid.SetAsteroid(rotation*-spawnDirection);
        }
    }
}
